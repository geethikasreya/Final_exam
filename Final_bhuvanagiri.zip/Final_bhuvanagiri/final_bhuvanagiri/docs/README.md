# CSCI 6313 — Final Examination (Complete Project)

This repository contains **all working pages** required by the exam prompt:
- Part 01: `index.html` (semantic HTML + external CSS)
- Part 02: `form.html` (contact/account form with **client‑side validation**)
- Part 03: `map.html` (Google Maps + Places; shows **top 5** results as cards)
- Part 04: SEO & WCAG optimizations (titles, meta description, one `<h1>`, alt text, keyboard nav, contrast)
- Part 05: GitHub Pages + documentation (this README and `docs/screens` placeholders)

## How to run locally
1. Open any file with a local web server (e.g., VS Code **Live Server**).
2. For the map page, edit `map.html` and replace `YOUR_API_KEY` with your actual Google Maps JavaScript API key.

## Validation Rule (Part 02)
New password must be **≥ 9 characters**, contain **exactly 2 uppercase** letters and **exactly 1 special symbol** (any non‑alphanumeric). See `assets/js/form.js` for the logic.

## GitHub Pages (Part 05)
- Push the repo.
- Enable Pages from **Settings → Pages** (root or `/docs`).
- Add screenshots to `docs/screens/`:
  - `part01_home_desktop.png` and `part01_home_mobile.png`
  - `part02_form_invalid.png` and `part02_form_valid.png`
  - `part03_map_cards.png`
  - `part04_a11y_report.png`
  - `part05_deployed.png`

